import React from "react";
import { View } from "react-native";
import Title from "./comps/Title";
import ContinueAs from "./comps/ContinueAs";
import GoogleButton from "./comps/GoogleButton";
import FacebookButton from "./comps/FacebookButton";
import Or from "./comps/Or";
import ReviewStars from "./comps/ReviewStars";
import WriteReview from "./comps/WriteReview";
import YourReview from "./comps/YourReview";
import FootBar from "./comps/FootBar";
import EventInfo from "./comps/EventInfo";
import DogInfo from "./comps/DogInfo";
import DogLikes from "./comps/DogLikes";
import UserInfo from "./comps/UserInfo";
import WalkerProfile from "./comps/WalkerProfile";
import DogInfoTitle from "./comps/DogInfoTitle";
import Posts from "./comps/Posts";
import ShareFeedback from "./comps/ShareFeedback";

const App = () => {
  return (
    <View>
      <Title />
      <ContinueAs />
      <GoogleButton />
      <Or />
      <FacebookButton />
      <ReviewStars />
      <WriteReview />
      <YourReview />
      <FootBar />
      <EventInfo />
      <DogInfo />
      <DogLikes />
      <UserInfo />
      <WalkerProfile />
      <DogInfoTitle />
      <Posts />
      <ShareFeedback />
    </View>
  );
};

export default App;
